package com.example.myfirstcalculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
